window.addEventListener("load", function () {
    const divDetalii = document.getElementById("detalii");
    const spanData = document.getElementById("dataProdus");
    const btn = document.getElementById("btnDetalii");

    // Ascunde secțiunea de detalii la încărcarea paginii
    divDetalii.classList.add("ascuns");

    
    const luni = [
        "Ianuarie", "Februarie", "Martie", "Aprilie", "Mai", "Iunie",
        "Iulie", "August", "Septembrie", "Octombrie", "Noiembrie", "Decembrie"
    ];

   
    const azi = new Date();
    const zi = azi.getDate();
    const luna = luni[azi.getMonth()];
    const an = azi.getFullYear();

  
    spanData.textContent = `${zi} ${luna} ${an}`;

   
    btn.addEventListener("click", function () {
        divDetalii.classList.toggle("ascuns");

        if (divDetalii.classList.contains("ascuns")) {
            btn.textContent = "Afișează detalii";
        } else {
            btn.textContent = "Ascunde detalii";
        }
    });
});
